rootProject.name = "TradeMaster1"

